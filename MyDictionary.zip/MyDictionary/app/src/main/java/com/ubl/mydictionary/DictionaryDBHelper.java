package com.ubl.mydictionary;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class DictionaryDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "dictionary.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "dictionary";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_ENGLISH = "english";
    public static final String COLUMN_INDONESIA = "indonesia";
    
    private static final String CREATE_TABLE_SQL =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ENGLISH + " TEXT NOT NULL UNIQUE, " +
                    COLUMN_INDONESIA + " TEXT NOT NULL" +
                    ");";

    public DictionaryDBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SQL);
        insertInitialData(db);
    }

    private void insertInitialData(SQLiteDatabase db) {
        String[][] data = {
                {"Apple", "Apel"},
                {"Book", "Buku"},
                {"Car", "Mobil"},
                {"Dream", "Mimpi"},
                {"Eat", "Makan"}
        };

        for (String[] pair : data) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_ENGLISH, pair[0]);
            values.put(COLUMN_INDONESIA, pair[1]);
            db.insert(TABLE_NAME, null, values);
        }
    }

    public long addEntry(String english, String indonesia) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ENGLISH, english);
        values.put(COLUMN_INDONESIA, indonesia);
        return db.insert(TABLE_NAME, null, values);
    }

    public String queryTranslation(String english) {
        SQLiteDatabase db = this.getReadableDatabase();
        String translation = null;
        Cursor cursor = db.query(
                TABLE_NAME,
                new String[]{COLUMN_INDONESIA},
                COLUMN_ENGLISH + " = ?",
                new String[]{english},
                null, null, null
        );

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                translation = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INDONESIA));
            }
            cursor.close();
        }
        return translation;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
