package com.ubl.mydictionary;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AddDataActivity extends AppCompatActivity {

    private DictionaryDBHelper dbHelper;
    private EditText etAddEnglish, etAddIndonesia;
    private TextView tvAddMessage;
    private Button btnSave, btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        dbHelper = new DictionaryDBHelper(this);

        etAddEnglish = findViewById(R.id.etAddEnglish);
        etAddIndonesia = findViewById(R.id.etAddIndonesia);
        tvAddMessage = findViewById(R.id.tvAddMessage);
        btnSave = findViewById(R.id.btnSave);
        btnBack = findViewById(R.id.btnBack);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void saveData() {
        String english = etAddEnglish.getText().toString().trim();
        String indonesia = etAddIndonesia.getText().toString().trim();

        boolean isValid = true;
        if (english.isEmpty()) {
            etAddEnglish.setError("English cannot be empty");
            isValid = false;
        }
        if (indonesia.isEmpty()) {
            etAddIndonesia.setError("Indonesia cannot be empty");
            isValid = false;
        }

        if (!isValid) {
            if (tvAddMessage != null) {
                tvAddMessage.setText("Please fill in all fields");
                tvAddMessage.setVisibility(View.VISIBLE);
            }
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DictionaryDBHelper.COLUMN_ENGLISH, english);
        values.put(DictionaryDBHelper.COLUMN_INDONESIA, indonesia);

        long id = db.insert(DictionaryDBHelper.TABLE_NAME, null, values);

        if (id == -1) {
            if (tvAddMessage != null) {
                tvAddMessage.setText("Failed to save. Maybe word already exists.");
                tvAddMessage.setVisibility(View.VISIBLE);
            }
        } else {
            if (tvAddMessage != null) {
                tvAddMessage.setText("Saved");
                tvAddMessage.setVisibility(View.VISIBLE);
                tvAddMessage.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                }, 800);
            } else {
                finish();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
